package userInterfaces;
import java.util.Scanner;
public class ConsoleIO implements InputOutputInterface {

    Scanner s = new Scanner(System.in);

    @Override
    public String readString(String prompt) {
        System.out.println(prompt);
        String reply = s.nextLine();
        while ( reply.length() == 0){
            reply = s.nextLine();
        }
        return reply;
    }

    @Override
    public int readInt(String prompt) {
        System.out.println(prompt);
        int num = 0;
        String reply = "";
        while ( reply.length() == 0){
            reply = s.nextLine();
            try{
                num = Integer.parseInt(reply);
            } catch (RuntimeException e){
                System.out.println("Please enter an int: ");
                reply = "";
                }
            }

        return num;
    }

    @Override
    public int readChoice(String[] options) {
        String greet = "Please select one.";
        for (String s:options){
            greet = greet + "\n" + s;
        }
        System.out.println(greet);
        return s.nextInt() -1;
    }

    @Override
    public void outputString(String outString) {System.out.println(outString);

    }
}
