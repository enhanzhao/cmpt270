//Enhan Zhao enz889 11097118 cmpt270


import java.util.Scanner;
import java.util.Collection;


import commands.*;
import entities.*;
import containers.*;
import userInterfaces.*;


/**
 * A simple hospital system with only one ward.  Patients and doctors can be created,
 * and patients assigned to a doctor and/or placed in a bed of the ward.
 */
public class HospitalSystem
{
    InputOutputInterface ioInterface;

    /**
     * Initialize an instance of the hospital ward
     * relies on user-input to get the relavent information
     */
    public HospitalSystem() {
        // get the ward information
        String[] options = {"ConsoleIO", "DialogIO"};
        DialogIO d = new DialogIO();
        int choice = d.readChoice(options);

        if (choice == 0){
            this.ioInterface = new ConsoleIO();
        }
        else{
            this.ioInterface = new DialogIO();
        }


        ioInterface.outputString("Initializing the system...");
        ioInterface.outputString("Getting Ward information...");
        String name = ioInterface.readString("Enter the name of the Ward: ");
        int firstBedNum = ioInterface.readInt("Enter the integer label of the first bed: ");
        int lastBedNum = ioInterface.readInt("Enter the integer label of the last bed: ");
        WardAccess.initialize(name, firstBedNum, lastBedNum);

    }

    /**
     * Read the information for a new patient and then add the patient
     * to the dictionary of all patients.
     */
    private void addPatient()
    {
        ioInterface.outputString("Getting Patient information...");
        String name = ioInterface.readString("Enter the name of the patient: ");

        int healthNum = ioInterface.readInt("Enter the health number of the patient: ");
        if (PatientMapAccess.dictionary().getPatient().containsKey(healthNum))
        {
            throw new RuntimeException("Patient with the health number " + healthNum + " already exsists");
        }
        else
        {
            Patient p = new Patient(name, healthNum);
            Patient result = PatientMapAccess.dictionary().getPatient().put(healthNum, p);

            // checking to make sure the the key was unique
            if (result != null)
            {
                PatientMapAccess.dictionary().getPatient().put(healthNum, result);  // put the original patient back
                throw new RuntimeException("Health number in the patient dictionary even "
                        + "though containsKey failed.  Number " + healthNum + " not entered.");
            }
        }
    }

    /**
     * Read the information for a new doctor and then add the doctor
     * to the dictionary of all doctors.
     */
    private void addDoctor()
    {

        NewDoctor n = new NewDoctor();

        ioInterface.outputString("Getting Patient information...");
        String name = ioInterface.readString("Enter the name of the doctor: ");
        String response = ioInterface.readString("Is the doctor a surgeon? (yes or no)");
        n.addDoctor(name, response);


    }

    /**
     * Assign a doctor to take care of a patient.
     */
    private void assignDoctorToPatient()
    {
        AssignDoctor a = new AssignDoctor();

        ioInterface.outputString("Assigning a new Doctor-Patient Association...");
        ioInterface.outputString("Getting Patient information...");
        int healthNumber = ioInterface.readInt("Enter the health number of the patient: ");
        ioInterface.outputString("Getting Patient information...");
        String name = ioInterface.readString("Enter the name of the doctor");
        a.assignDoctorToPatient(name, healthNumber);

    }

    /**
     * Assign a patient to a specific bed.
     */
    private void assignBed()
    {
        ioInterface.outputString("Assigning a Patient to a Bed...");
        ioInterface.outputString("Getting Patient information...");
        int healthNumber = ioInterface.readInt("Enter the health number of the patient: ");

        Patient p = PatientMapAccess.dictionary().getPatient().get(healthNumber);
        if (p == null)
            throw new RuntimeException("There is no patient with health number "
                    + healthNumber);

        if (p.getBedLabel() != -1)
            throw new RuntimeException(" Patient " + p
                    + " is already in a bed so cannot be assigned a new bed");

        int bedNum = ioInterface.readInt("Enter the bed number for the patient: ");

        if (bedNum < WardAccess.Ward().getMinBedLabel() || bedNum > WardAccess.Ward().getMaxBedLabel())
            throw new RuntimeException("Bed label " + bedNum + " is not valid, as "
                    + "the value must be between " + WardAccess.Ward().getMinBedLabel()
                    + " and " + WardAccess.Ward().getMaxBedLabel());

        p.setBedLabel(bedNum);
        WardAccess.Ward().assignPatientToBed(p, bedNum);
    }

    /**
     * Drop the association between a doctor and a patient.
     */
    private void dropAssociation()
    {
        DropDoctor d = new DropDoctor();

        ioInterface.outputString("Dropping a new Doctor-Patient Association...");
        ioInterface.outputString("Getting Patient information...");
        int healthNumber = ioInterface.readInt("Enter the health number of the patient: ");

        ioInterface.outputString("Getting Doctor information...");
        String name = ioInterface.readString("Enter the name of the doctor: ");

        d.dropAssociation(healthNumber, name);
    }

    /**
     * Displays the system state
     */
    private void systemState()
    {
        System.out.println(this.toString());
    }

    /**
     * Return a string representation of the HospitalSystem
     * @return a string representation of the HospitalSystem
     */
    public String toString() {
        String result = "\nThe patients in the system are \n";
        Collection<Patient> patientsColl = PatientMapAccess.dictionary().getPatient().values();
        for (Patient p: patientsColl)
            result = result + p;
        result = result + "\nThe doctors in the system are \n";
        Collection<Doctor> doctorsColl = DoctorMapAccess.dictionary().getDoctors().values();
        for (Doctor d: doctorsColl)
            result = result + d;
        result = result + "\nThe ward is " + WardAccess.Ward();
        return result;
    }

    /**
     * Display the empty beds for the ward.
     * Method is just a stub, needs to be implemented
     */
    public void displayEmptyBeds()
    {
        EmptyBeds b = new EmptyBeds();
        b.displayEmptyBeds();
    }


    /**
     * Release a patient from the ward.
     */
    private void releasePatient(int healthnum){
        Patient p = PatientMapAccess.dictionary().getPatient().get(healthnum);
        WardAccess.Ward().freeBed(p.getBedLabel());
        while (p.getDoctorList().size() != 0){
            Doctor d = p.getDoctorList().getFirst();
            d.removePatient(p.getHealthNumber());
            p.removeDoctor(d.getName());
        }
        PatientMapAccess.dictionary().getPatient().remove(p.getHealthNumber());
        ;
    }

    /**
     * Run the hospital system.
     * @param args not used
     */
    public static void main(String[] args)
    {
        int task = -1;
        String[] choices = {"1: quit", "2: add a new patient", "3: add a new doctor", "4: assign a doctor to a patient", "5: display the empty beds of the ward",
        "6: assign a patient to a bed", "7: release a patient", "8: drop doctor patient association", "9: display current system state\n"};
        HospitalSystem sys = new HospitalSystem();

        try{
            while(task != 0) {
                task = sys.ioInterface.readChoice(choices);
                if (task == 0)
                    sys.systemState();
                else if (task == 1)
                    sys.addPatient();
                else if (task == 2)
                    sys.addDoctor();
                else if (task == 3)
                    sys.assignDoctorToPatient();
                else if (task == 4)
                    sys.displayEmptyBeds();
                else if (task == 5)
                    sys.assignBed();
                else if (task == 6){
                    int healthN = sys.ioInterface.readInt("Enter the patient health card number: ");
                    sys.releasePatient(healthN);}
                else if (task == 7)
                    sys.dropAssociation();
                else if (task == 8)
                    sys.systemState();
                else
                    sys.ioInterface.outputString("Invalid option, try again.");
            }
        } catch (RuntimeException e) {
            sys.ioInterface.outputString(e.getMessage());
        } finally {
            ;
        }
    }
}