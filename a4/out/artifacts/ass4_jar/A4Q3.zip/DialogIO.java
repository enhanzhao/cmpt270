package userInterfaces;

import javax.swing.*;

public class DialogIO extends  AbstractDialogIO {
    @Override
    public String readString(String prompt) {
        String choice = JOptionPane.showInputDialog(null, prompt);
        while (choice.length()== 0){
            choice = JOptionPane.showInputDialog(null, prompt);
        }
        return choice;
    }

    @Override
    public int readInt(String prompt) {
        int i =0;
        String choice = "";
        while (choice.length() == 0){
            choice = JOptionPane.showInputDialog(null, prompt);
            try{
                i = Integer.parseInt(choice);
            }catch (RuntimeException e) {
                System.out.print("Enter integer: ");
                choice = "";
            }
        }

        return i;
    }

    @Override
    public void outputString(String outString) {
        JOptionPane.showMessageDialog(null, outString + "\n");

    }
}
