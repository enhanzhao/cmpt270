//Enhan Zhao enz889 11097118 cmpt270


import java.util.Scanner;
import java.util.Collection;


import commands.*;
import entities.*;
import containers.*;

/**
 * A simple hospital system with only one ward.  Patients and doctors can be created,
 * and patients assigned to a doctor and/or placed in a bed of the ward.
 */
public class HospitalSystem
{

    /**
     * Initialize an instance of the hospital ward
     * relies on user-input to get the relavent information
     */
    public HospitalSystem() {
        // get the ward information
        Scanner consoleIn = new Scanner(System.in);

        System.out.println("Initializing the system...");
        System.out.println("Getting Ward information...");
        System.out.print("Enter the name of the Ward: ");
        String name = consoleIn.nextLine();
        System.out.print("Enter the integer label of the first bed: ");
        int firstBedNum = consoleIn.nextInt();
        consoleIn.nextLine();
        System.out.print("Enter the integer label of the last bed: ");
        int lastBedNum = consoleIn.nextInt();
        consoleIn.nextLine();
        WardAccess.initialize(name, firstBedNum, lastBedNum);

    }

    /**
     * Read the information for a new patient and then add the patient
     * to the dictionary of all patients.
     */
    private void addPatient()
    {
        Scanner consoleIn = new Scanner(System.in);

        System.out.println("Getting Patient information...");
        System.out.print("Enter the name of the patient: ");
        String name = consoleIn.nextLine();

        System.out.print("Enter the health number of the patient: ");
        int healthNum = consoleIn.nextInt();
        consoleIn.nextLine();  // discard the remainder of the line
        if (PatientMapAccess.dictionary().getPatient().containsKey(healthNum))
        {
            throw new RuntimeException("Patient with the health number " + healthNum + " already exsists");
        }
        else
        {
            Patient p = new Patient(name, healthNum);
            Patient result = PatientMapAccess.dictionary().getPatient().put(healthNum, p);

            // checking to make sure the the key was unique
            if (result != null)
            {
                PatientMapAccess.dictionary().getPatient().put(healthNum, result);  // put the original patient back
                throw new RuntimeException("Health number in the patient dictionary even "
                        + "though containsKey failed.  Number " + healthNum + " not entered.");
            }
        }
    }

    /**
     * Read the information for a new doctor and then add the doctor
     * to the dictionary of all doctors.
     */
    private void addDoctor()
    {
        Scanner consoleIn = new Scanner(System.in);
        NewDoctor n = new NewDoctor();

        System.out.println("Getting Patient information...");
        System.out.print("Enter the name of the doctor: ");
        String name = consoleIn.nextLine();
        System.out.print("Is the doctor a surgeon? (yes or no)");
        String response = consoleIn.nextLine();

        n.addDoctor(name, response);


    }

    /**
     * Assign a doctor to take care of a patient.
     */
    private void assignDoctorToPatient()
    {
        Scanner consoleIn = new Scanner(System.in);
        AssignDoctor a = new AssignDoctor();

        System.out.println("Assigning a new Doctor-Patient Association...");
        System.out.println("Getting Patient information...");
        System.out.print("Enter the health number of the patient: ");
        int healthNumber = consoleIn.nextInt();
        consoleIn.nextLine();  // discard the remainder of the line
        System.out.println("Getting Patient information...");
        System.out.println("Enter the name of the doctor");
        String name = consoleIn.nextLine();
        a.assignDoctorToPatient(name, healthNumber);

    }

    /**
     * Assign a patient to a specific bed.
     */
    private void assignBed()
    {
        Scanner consoleIn = new Scanner(System.in);

        System.out.println("Assigning a Patient to a Bed...");
        System.out.println("Getting Patient information...");
        System.out.print("Enter the health number of the patient: ");
        int healthNumber = consoleIn.nextInt();
        consoleIn.nextLine();  // discard the remainder of the line

        Patient p = PatientMapAccess.dictionary().getPatient().get(healthNumber);
        if (p == null)
            throw new RuntimeException("There is no patient with health number "
                    + healthNumber);

        if (p.getBedLabel() != -1)
            throw new RuntimeException(" Patient " + p
                    + " is already in a bed so cannot be assigned a new bed");

        System.out.print("Enter the bed number for the patient: ");
        int bedNum = consoleIn.nextInt();
        consoleIn.nextLine();  // discard the remainder of the line
        if (bedNum < WardAccess.Ward().getMinBedLabel() || bedNum > WardAccess.Ward().getMaxBedLabel())
            throw new RuntimeException("Bed label " + bedNum + " is not valid, as "
                    + "the value must be between " + WardAccess.Ward().getMinBedLabel()
                    + " and " + WardAccess.Ward().getMaxBedLabel());

        p.setBedLabel(bedNum);
        WardAccess.Ward().assignPatientToBed(p, bedNum);
    }

    /**
     * Drop the association between a doctor and a patient.
     */
    private void dropAssociation()
    {
        Scanner consoleIn = new Scanner(System.in);
        DropDoctor d = new DropDoctor();

        System.out.println("Dropping a new Doctor-Patient Association...");
        System.out.println("Getting Patient information...");
        System.out.print("Enter the health number of the patient: ");
        int healthNumber = consoleIn.nextInt();
        consoleIn.nextLine();  // discard the remainder of the line

        System.out.println("Getting Doctor information...");
        System.out.print("Enter the name of the doctor: ");
        String name = consoleIn.nextLine();

        d.dropAssociation(healthNumber, name);
    }

    /**
     * Displays the system state
     */
    private void systemState()
    {
        System.out.println(this.toString());
    }

    /**
     * Return a string representation of the HospitalSystem
     * @return a string representation of the HospitalSystem
     */
    public String toString() {
        String result = "\nThe patients in the system are \n";
        Collection<Patient> patientsColl = PatientMapAccess.dictionary().getPatient().values();
        for (Patient p: patientsColl)
            result = result + p;
        result = result + "\nThe doctors in the system are \n";
        Collection<Doctor> doctorsColl = DoctorMapAccess.dictionary().getDoctors().values();
        for (Doctor d: doctorsColl)
            result = result + d;
        result = result + "\nThe ward is " + WardAccess.Ward();
        return result;
    }

    /**
     * Display the empty beds for the ward.
     * Method is just a stub, needs to be implemented
     */
    public void displayEmptyBeds()
    {
        EmptyBeds b = new EmptyBeds();
        b.displayEmptyBeds();
    }


    /**
     * Release a patient from the ward.
     */
    private void releasePatient(int healthnum){
        Patient p = PatientMapAccess.dictionary().getPatient().get(healthnum);
        WardAccess.Ward().freeBed(p.getBedLabel());
        while (p.getDoctorList().size() != 0){
            Doctor d = p.getDoctorList().getFirst();
            d.removePatient(p.getHealthNumber());
            p.removeDoctor(d.getName());
        }
        PatientMapAccess.dictionary().getPatient().remove(p.getHealthNumber());
        ;
    }

    /**
     * Run the hospital system.
     * @param args not used
     */
    public static void main(String[] args)
    {
        Scanner consoleIn = new Scanner(System.in);
        int task = -1;

        HospitalSystem sys = new HospitalSystem();

        try{
            while(task != 1) {
                System.out.print("Please select an operation to do"
                        + "\n1: quit"
                        + "\n2: add a new patient"
                        + "\n3: add a new doctor"
                        + "\n4: assign a doctor to a patient"
                        + "\n5: display the empty beds of the ward"
                        + "\n6: assign a patient a bed"
                        + "\n7: release a patient"
                        + "\n8: drop doctor-patient association"
                        + "\n9: display current system state"
                        + "\nEnter the number of your selection: ");

                task = consoleIn.nextInt();
                consoleIn.nextLine();

                if (task == 1)
                    sys.systemState();
                else if (task == 2)
                    sys.addPatient();
                else if (task == 3)
                    sys.addDoctor();
                else if (task == 4)
                    sys.assignDoctorToPatient();
                else if (task == 5)
                    sys.displayEmptyBeds();
                else if (task == 6)
                    sys.assignBed();
                else if (task == 7){
                    System.out.println("Enter the patient health card number: ");
                    int healthN = consoleIn.nextInt();
                    sys.releasePatient(healthN);}
                else if (task == 8)
                    sys.dropAssociation();
                else if (task == 9)
                    sys.systemState();
                else
                    System.out.println("Invalid option, try again.");
            }
        } catch (RuntimeException e) {
            System.out.println(e.getMessage());
        } finally {
            consoleIn.close();
        }
    }
}